import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) throws NoSuchElementException{
        GUI gui = new GUI();
        gui.start();
    }
}
