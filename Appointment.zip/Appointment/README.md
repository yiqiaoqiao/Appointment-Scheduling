The project requires Java mail to run.
Project which user is able to ask questions about counseling and get responses for general questions.
If user does not get the questions wanted, user can make appointment with counselor, and get email notification.